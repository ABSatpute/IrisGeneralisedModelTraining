import numpy as np
import pandas as pd
import json
import logging
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.preprocessing import StandardScaler, FunctionTransformer
from sklearn.decomposition import PCA
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.ensemble import RandomForestRegressor, GradientBoostingClassifier, GradientBoostingClassifier
from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR
from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import LinearRegression
from sklearn.base import BaseEstimator, TransformerMixin


# Logging configuration
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


# Load JSON configuration
def load_json(file_path):
    try:
        with open(file_path, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.error(f"JSON file not found at path: {file_path}")
        raise


# Load dataset
def load_dataset(file_path):
    try:
        return pd.read_csv(file_path)
    except FileNotFoundError:
        logging.error(f"Dataset not found at path: {file_path}")
        raise


# Data preprocessing
def datapreprocessing(feature_handling):
    numerical_features = [
        feature for feature, config in feature_handling.items()
        if config["is_selected"] and config["feature_variable_type"] == "numerical"
    ]
    text_features = [
        feature for feature, config in feature_handling.items()
        if config["is_selected"] and config["feature_variable_type"] == "text"
    ]

    numerical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='mean'))
    ]) if numerical_features else 'drop'

    text_transformers = [
        (feature, Pipeline([
            ('hashing', HashingVectorizer(
                n_features=max(config.get('feature_details', {}).get('hash_columns', 10), 1),
                analyzer='word'
            )),
            ('to_dense', FunctionTransformer(lambda x: x.toarray(), accept_sparse=True))
        ]), [feature]) for feature, config in feature_handling.items()
        if feature in text_features
    ]

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numerical_transformer, numerical_features),
            *text_transformers
        ],
        remainder='drop'  # Avoid passing unprocessed columns
    )
    return preprocessor


# Feature reduction
def feature_reduction(preprocessor, feature_reduction, target, df):
    method = feature_reduction["feature_reduction_method"]

    if method == "PCA":
        n_components = int(feature_reduction["num_of_features_to_keep"])
        return Pipeline([
            ("preprocessor", preprocessor),
            ("reduction", PCA(n_components=n_components))
        ])
    elif method == "No Reduction":
        return Pipeline([
            ("preprocessor", preprocessor)
        ])
    elif method == "Corr With Target":
        def select_high_corr_features(X, y, k):
            correlations = X.corrwith(y).abs()
            top_features = correlations.nlargest(k).index.tolist()
            return X[top_features]

        k = int(feature_reduction["num_of_features_to_keep"])
        return Pipeline([
            ("preprocessor", preprocessor),
            ("corr_selector", BaseEstimator())
        ])
    elif method == "Tree-based":
        num_features_keep = int(feature_reduction["num_of_features_to_keep"])
        tree_model = RandomForestRegressor(random_state=42, n_estimators=100)
        selector = SelectFromModel(tree_model, max_features=num_features_keep, threshold=-np.inf)
        return Pipeline([
            ("preprocessor", preprocessor),
            ("tree_selector", selector)
        ])
    else:
        raise ValueError(f"Unknown feature reduction method: {method}")


# Initialize models
def models_init(config):
    for algo, details in config["design_state_data"]["algorithms"].items():
        if details["is_selected"]:
            if algo == "RandomForestClassifier":
                param_grid = {
                    "model__n_estimators": range(details["min_trees"], details["max_trees"] + 1, 10),
                    "model__max_depth": range(details["min_depth"], details["max_depth"] + 1, 5),
                }
                return RandomForestClassifier(random_state=42), param_grid

            elif algo == "DecisionTreeClassifier":
                param_grid = {
                    "model__max_depth": range(details["min_depth"], details["max_depth"] + 1, 5),
                }
                return DecisionTreeClassifier(random_state=42), param_grid

            elif algo == "GradientBoostingClassifier":
                param_grid = {
                    "model__n_estimators": range(details["min_trees"], details["max_trees"] + 1, 10),
                    "model__learning_rate": [0.01, 0.05, 0.1, 0.2],
                    "model__max_depth": range(details["min_depth"], details["max_depth"] + 1, 5),
                }
                return GradientBoostingClassifier(random_state=42), param_grid

            elif algo == "LogisticRegression":
                param_grid = {
                    "model__C": [0.1, 1, 10],
                    "model__penalty": ["l1", "l2", "elasticnet", "none"],
                    "model__solver": ["liblinear", "lbfgs"],
                }
                return LogisticRegression(max_iter=1000), param_grid

            elif algo == "SVC":
                param_grid = {
                    "model__kernel": details.get("kernel_options", ["rbf", "linear", "poly"]),
                    "model__C": [0.1, 1, 10],
                    "model__gamma": ["scale", "auto"],
                }
                return SVC(), param_grid

            elif algo == "KNeighborsClassifier":
                param_grid = {
                    "model__n_neighbors": range(3, 15, 2),
                    "model__weights": ["uniform", "distance"],
                }
                return KNeighborsClassifier(), param_grid

            # Regression Models
            elif algo == "RandomForestRegressor":
                param_grid = {
                    "model__n_estimators": range(details["min_trees"], details["max_trees"] + 1, 10),
                    "model__max_depth": range(details["min_depth"], details["max_depth"] + 1, 5),
                }
                return RandomForestRegressor(random_state=42), param_grid

            elif algo == "DecisionTreeRegressor":
                param_grid = {
                    "model__max_depth": range(details["min_depth"], details["max_depth"] + 1, 5),
                }
                return DecisionTreeRegressor(random_state=42), param_grid

            elif algo == "GradientBoostingRegressor":
                param_grid = {
                    "model__n_estimators": range(details["min_trees"], details["max_trees"] + 1, 10),
                    "model__learning_rate": [0.01, 0.05, 0.1, 0.2],
                    "model__max_depth": range(details["min_depth"], details["max_depth"] + 1, 5),
                }
                return GradientBoostingRegressor(random_state=42), param_grid

            elif algo == "SVR":
                param_grid = {
                    "model__kernel": details.get("kernel_options", ["rbf", "linear", "poly"]),
                    "model__C": [0.1, 1, 10],
                    "model__epsilon": [0.01, 0.1, 0.2],
                }
                return SVR(), param_grid

            elif algo == "KNeighborsRegressor":
                param_grid = {
                    "model__n_neighbors": range(3, 15, 2),
                    "model__weights": ["uniform", "distance"],
                }
                return KNeighborsRegressor(), param_grid

            elif algo == "LinearRegression":
                return LinearRegression(), {}

    raise ValueError("No valid algorithm is selected in the JSON configuration.")


# Train and evaluate models
def train_and_evaluate(config, df):
    
    feature_handling = config["design_state_data"]["feature_handling"]
    feature_reduction_config = config["design_state_data"]["feature_reduction"]
    target = config["design_state_data"]["target"]["target"]
    
    # Preprocess the data
    preprocessor = datapreprocessing(feature_handling)
    
    pipeline = feature_reduction(preprocessor, feature_reduction_config, target, df)
    print(pipeline)
    
    # Split dataset
    X = df.loc[:, df.columns != target]
    y = df[target]
    

    train_ratio = config["design_state_data"]["train"]["train_ratio"] or 0.8
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=train_ratio, random_state=42)
    print(preprocessor.fit_transform(X))
    # Initialize model
    
    model, param_grid = models_init(config)
    
    # Add model to pipeline
    pipeline.steps.append(("model", model))

    # Hyperparameter tuning with GridSearchCV
    grid_search = GridSearchCV(pipeline, param_grid,error_score='raise', cv=5, scoring="r2", verbose=1, n_jobs=-1)
    
    grid_search.fit(X_train, y_train)
    
    # Evaluate model
    y_pred = grid_search.best_estimator_.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)

    # # Log results
    # logging.info(f"Best Parameters: {grid_search.best_params_}")
    # logging.info(f"Mean Squared Error: {mse}")
    # logging.info(f"R2 Score: {r2}")

    return grid_search.best_estimator_


if __name__ == "__main__":
    json_path = "algoparams_from_ui.json"  # Path to JSON configuration
    dataset_path = "iris.csv"  # Path to dataset (update with your file path)

    try:
        # Load JSON and dataset
        config = load_json(json_path)
        df = load_dataset(dataset_path)
        
        # Train and evaluate
        best_model = train_and_evaluate(config, df)
    
    except FileNotFoundError as e:
        logging.error(f"File not found: {e}")
    except KeyError as e:
        logging.error(f"Missing key in JSON configuration: {e}")
    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}")
