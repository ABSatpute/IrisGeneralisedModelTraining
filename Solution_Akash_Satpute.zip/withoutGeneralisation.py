import pandas as pd
import numpy as np
import json
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_squared_error, r2_score


# Step 1: Load JSON and Dataset
def load_config_and_data(json_path, csv_path):
    with open(json_path, "r") as file:
        config = json.load(file)
    data = pd.read_csv(csv_path)
    return config, data


# Step 2: Handle Missing Values
def build_preprocessor(config, numerical_features, categorical_features):
    numerical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="mean")),
        ("scaler", StandardScaler())
    ])
    
    return ColumnTransformer(transformers=[
        ("num", numerical_transformer, numerical_features),
    ])


# Step 3: Feature Reduction
def get_feature_reduction_method(config):
    method = config["design_state_data"]["feature_reduction"]["feature_reduction_method"]
    if method == "PCA":
        n_components = int(config["design_state_data"]["feature_reduction"]["num_of_features_to_keep"])
        return PCA(n_components=n_components)
    else:
        return "passthrough"  # No Reduction









# Step 4: Build the Model
def get_model_and_params(config):
    for algo, details in config["design_state_data"]["algorithms"].items():
        if details["is_selected"]:
            if algo == "RandomForestRegressor":
                param_grid = {
                    "model__n_estimators": range(details["min_trees"], details["max_trees"] + 1, 10),
                    "model__max_depth": range(details["min_depth"], details["max_depth"] + 1, 5),
                }
                return RandomForestRegressor(), param_grid
    return None, None


# Step 5: Build Pipeline and Train
def build_pipeline(preprocessor, feature_reduction, model):
    return Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("reduction", feature_reduction),
        ("model", model)
    ])


def train_and_evaluate(pipeline, param_grid, X_train, X_test, y_train, y_test):
    grid_search = GridSearchCV(pipeline, param_grid=param_grid, cv=3, scoring="r2")
    grid_search.fit(X_train, y_train)
    best_model = grid_search.best_estimator_

    y_pred = best_model.predict(X_test)
    print(f"Best Params: {grid_search.best_params_}")
    print(f"Mean Squared Error: {mean_squared_error(y_test, y_pred)}")
    print(f"R^2 Score: {r2_score(y_test, y_pred)}")


# Main Execution
if __name__ == "__main__":
    # Load configuration and data
    config_path = "algoparams_from_ui.json"
    data_path = "iris.csv"
    config, data = load_config_and_data(config_path, data_path)

    # Extract features and target
    target_column = config["design_state_data"]["target"]["target"]
    numerical_features = [col for col in data.columns if data[col].dtype in [np.float64, np.int64]]
    numerical_features.remove(target_column)
    categorical_features = [col for col in data.columns if data[col].dtype == "object"]

    # Preprocessing
    preprocessor = build_preprocessor(config, numerical_features, categorical_features)

    # Feature Reduction
    feature_reduction = get_feature_reduction_method(config)

    # Model and Parameters
    model, param_grid = get_model_and_params(config)

    # Build Pipeline
    pipeline = build_pipeline(preprocessor, feature_reduction, model)

    # Train-Test Split
    X = data.drop(target_column, axis=1)
    y = data[target_column]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train and Evaluate
    train_and_evaluate(pipeline, param_grid, X_train, X_test, y_train, y_test)
